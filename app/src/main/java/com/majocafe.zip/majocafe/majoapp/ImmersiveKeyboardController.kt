package com.majocafe.majoapp

import android.app.Activity
import android.graphics.Rect
import android.os.Build
import android.view.View
import android.view.ViewTreeObserver
import android.view.WindowManager
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.math.max

/** Variante con barras visibles. Conserva el nombre y métodos usados en MainActivity. */
class ImmersiveKeyboardController(private val activity: Activity, private val content: View) {
    private val decor = activity.window.decorView
    private val visibleFrame = Rect()
    private val location = IntArray(2)
    private var stopped = true
    private var started = false
    private var leftInset = 0
    private var topInset = 0
    private var rightInset = 0
    private var navigationBottom = 0
    private var fullWindowHeight = 0
    private var windowWidth = 0
    private val restore = Runnable {
        if (!stopped && !activity.isFinishing && !activity.isDestroyed && activity.hasWindowFocus()) {
            showSystemBars()
        }
    }
    private val legacyLayoutListener = ViewTreeObserver.OnGlobalLayoutListener { updateLegacyKeyboard() }

    fun start() {
        if (started) return
        started = true
        stopped = false
        WindowCompat.setDecorFitsSystemWindows(activity.window, false)
        // El fondo visible bajo las barras transparentes también es majo_coffee.
        content.setBackgroundColor(ContextCompat.getColor(activity, R.color.majo_coffee))
        showSystemBars()
        ViewCompat.setOnApplyWindowInsetsListener(content) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            leftInset = bars.left
            topInset = bars.top
            rightInset = bars.right
            navigationBottom = bars.bottom
            if (Build.VERSION.SDK_INT >= 30) {
                val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
                val bottom = if (insets.isVisible(WindowInsetsCompat.Type.ime())) max(bars.bottom, ime.bottom) else bars.bottom
                applyPadding(bottom)
            } else {
                updateLegacyKeyboard()
            }
            insets
        }
        if (Build.VERSION.SDK_INT < 30) decor.viewTreeObserver.addOnGlobalLayoutListener(legacyLayoutListener)
        ViewCompat.requestApplyInsets(content)
    }

    private fun applyPadding(bottom: Int) {
        if (content.paddingLeft != leftInset || content.paddingTop != topInset ||
            content.paddingRight != rightInset || content.paddingBottom != bottom) {
            content.setPadding(leftInset, topInset, rightInset, bottom)
        }
    }

    private fun updateLegacyKeyboard() {
        if (stopped || decor.height == 0) return
        if (decor.width != windowWidth) {
            windowWidth = decor.width
            fullWindowHeight = decor.height
        }
        fullWindowHeight = max(fullWindowHeight, decor.height)
        decor.getWindowVisibleDisplayFrame(visibleFrame)
        decor.getLocationOnScreen(location)
        val visibleBottom = (visibleFrame.bottom - location[1]).coerceAtLeast(0)
        val threshold = (100 * content.resources.displayMetrics.density).toInt()
        val keyboardVisible = fullWindowHeight - visibleBottom > threshold
        // Si adjustResize ya redujo la ventana, no descontar dos veces el teclado.
        val bottom = if (keyboardVisible) (decor.height - visibleBottom).coerceAtLeast(0) else navigationBottom
        applyPadding(bottom)
    }

    @Suppress("DEPRECATION")
    private fun showSystemBars() {
        val window = activity.window
        window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN or
            WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS or WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION)
        val coffee = ContextCompat.getColor(activity, R.color.majo_coffee)
        window.statusBarColor = coffee
        window.navigationBarColor = coffee
        if (Build.VERSION.SDK_INT >= 28) window.navigationBarDividerColor = coffee
        if (Build.VERSION.SDK_INT >= 29) {
            window.isStatusBarContrastEnforced = false
            window.isNavigationBarContrastEnforced = false
        }
        WindowCompat.getInsetsController(window, decor).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
            show(WindowInsetsCompat.Type.systemBars())
        }
    }

    fun restoreWhenReady() {
        if (stopped) return
        decor.removeCallbacks(restore)
        decor.post(restore)
    }

    fun stop() {
        stopped = true
        started = false
        decor.removeCallbacks(restore)
        ViewCompat.setOnApplyWindowInsetsListener(content, null)
        if (Build.VERSION.SDK_INT < 30 && decor.viewTreeObserver.isAlive) {
            decor.viewTreeObserver.removeOnGlobalLayoutListener(legacyLayoutListener)
        }
    }
}
