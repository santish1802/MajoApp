package com.majocafe.majoapp

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream

/** Prueba raster ESC/POS de 384 puntos; no envía un archivo PDF a la impresora. */
object ImageTestReceipt {
    fun bytes(context: Context): ByteArray {
        val bitmap = Bitmap.createBitmap(384, 480, Bitmap.Config.ARGB_8888)
        try {
            val canvas = Canvas(bitmap)
            canvas.drawColor(Color.WHITE)
            val logo = requireNotNull(ContextCompat.getDrawable(context, R.drawable.majo4)).mutate()
            logo.setTint(Color.BLACK)
            logo.setBounds(60, 0, 324, 264)
            logo.draw(canvas)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.BLACK
                textAlign = Paint.Align.CENTER
                textSize = 28f
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            }
            canvas.drawText("MAJO CAFETERÍA", 192f, 284f, paint)
            paint.textSize = 24f
            paint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.ITALIC)
            canvas.drawText("Prueba de texto en cursiva", 192f, 326f, paint)
            paint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            paint.textSize = 22f
            canvas.drawText("Logo + imagen · 58 mm", 192f, 364f, paint)
            canvas.drawLine(16f, 384f, 368f, 384f, paint)
            canvas.drawText("PRUEBA — SIN VALOR FISCAL", 192f, 418f, paint)
            canvas.drawText("Gracias por su visita", 192f, 452f, paint)
            return raster(bitmap)
        } finally {
            bitmap.recycle()
        }
    }

    // GS v 0, bloques de 48 filas para limitar el búfer de la ticketera.
    internal fun raster(bitmap: Bitmap): ByteArray {
        val rowBytes = (bitmap.width + 7) / 8
        return ByteArrayOutputStream().apply {
            var top = 0
            while (top < bitmap.height) {
                val height = minOf(48, bitmap.height - top)
                write(byteArrayOf(0x1D, 0x76, 0x30, 0x00,
                    (rowBytes and 255).toByte(), (rowBytes shr 8).toByte(),
                    (height and 255).toByte(), (height shr 8).toByte()))
                for (y in top until top + height) {
                    for (column in 0 until rowBytes) {
                        var bits = 0
                        for (bit in 0..7) {
                            val x = column * 8 + bit
                            if (x < bitmap.width) {
                                val pixel = bitmap.getPixel(x, y)
                                val luminance = (Color.red(pixel) * 299 + Color.green(pixel) * 587 + Color.blue(pixel) * 114) / 1000
                                if (luminance < 160) bits = bits or (0x80 shr bit)
                            }
                        }
                        write(bits)
                    }
                }
                top += height
            }
        }.toByteArray()
    }
}
